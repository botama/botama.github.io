# Jóga projekt

Inspiráció: [https://mandalaonline.hu/](https://mandalaonline.hu/).

## Felhasznált komponensek / Attribution

- [fontawesome.com](https://fontawesome.com) SVG icons. Link: [Attribution](https://fontawesome.com/license).
