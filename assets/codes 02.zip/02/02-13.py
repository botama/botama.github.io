sugár = (100/3.14)**0.5
print("A keresett védőkör sugara:", round(sugár, 2), "méter.")
