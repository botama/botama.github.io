# EGY LEHETSÉGES MEGOLDÁS

Alfa = input("Alfa? ")
Beta = input("Beta? ")
Gamma = input("Gamma? ")

print("Alfa:", Alfa)
print("Beta:", Beta)
print("Gamma:", Gamma)
