Erősség = input("Varázslat erőssége: ")  # Szöveges bekérés
Gyorsaság = input("Varázslat gyorsasága: ")  # Szöveges bekérés

# Hozzunk létre egy segéd változót
Hatásosság = Erősség + Gyorsaság  # Két szöveges érték összefűzése
print("A varázslat hatásossága " + Hatásosság + " pont.")

Hatásosság = int(Erősség) + int(Gyorsaság)  # Két egész szám összeadása
print("A varázslat hatásossága " + str(Hatásosság) + " pont.")
