aura = input("Mágikus arua nagysága: ")
aura = float(aura)  # tört számmá alakítás
aura = aura / 2  # osztás kettővel
# itt vesszővel elválasztva jelenítünk meg egymás után
print("Az erőtér nagysága:", aura)

aura = input("Mágikus arua nagysága: ")
# itt a szövegeket fűzzük össze
print("Az erőtér nagysága: " + str(float(aura)/2))

print("Az erőtér nagysága:", float(input("Mágikus arua nagysága: "))/2)
