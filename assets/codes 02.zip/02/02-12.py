terület = int(3.14 * int(input("A kör sugara (méterben):")) ** 2)
print("A védett terület negysága:", terület, "négyzetméter.")
