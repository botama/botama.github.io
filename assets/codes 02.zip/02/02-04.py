a = "démon"  # Ebbe a változóba egy szöveget rakunk
b = 13  # Ebbe pedig egy egész számot
c = 3.14  # Ebbe egy tört számot
d = True  # Ebbe pedig egy igaz értéket

# Most megjelenítjük a változók értékét és típusát
print(a, type(a))  # az a változó értéke és típusa
print(b, type(b))  # a b változó értéke és típusa
print(c, type(c))  # a c változó értéke és típusa
print(d, type(d))  # a d változó értéke és típusa
