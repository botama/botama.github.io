print("Összesen", 124 // 21, "goblin ellen tudnék védekezni.")
# vagy
print("Összesen", int(124 / 21), "goblin ellen tudnék védekezni.")

print("Összesen", 124 % 21, "manám marad a varázslat után.")
