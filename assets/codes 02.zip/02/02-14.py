goblin_1 = goblin_2 = goblin_3 = "goblin"  # gyors létrehozás
sorszám = 1  # a sorszám kezdeti értéke
goblin_1 = str(sorszám) + ". " + goblin_1
sorszám = sorszám + 1  # hozzáadunk egyet a jelenlegi értékéhez
goblin_2 = str(sorszám) + ". " + goblin_2
sorszám += 1  # így gyorsabban hozzá tudunk adni egyet
goblin_3 = str(sorszám) + ". " + goblin_3
print(goblin_1, goblin_2, goblin_3)
