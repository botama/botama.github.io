bal_kéz = 42  # most ide fókuszálunk éppen
jobb_kéz = 0  # itt pedig nincs varázserő

print("Bal kéz előtte:", bal_kéz)
print("Jobb kéz előtte:", jobb_kéz)

mana_tároló = bal_kéz  # egy segéd változóba rakjuk a bal kéz tartalmát
bal_kéz = jobb_kéz  # a bal kkézbe rakjuk a jobb kéz tartalmát
jobb_kéz = mana_tároló  # a jobb kézbe rakjuk a segéd változó tartalmát

print("Bal kéz utána:", bal_kéz)
print("Jobb kéz utána:", jobb_kéz)

# most pedig visszacseréljük a két kezet egy másik módszerrel
bal_kéz, jobb_kéz = jobb_kéz, bal_kéz

print("Bal kéz utána:", bal_kéz)
print("Jobb kéz utána:", jobb_kéz)
