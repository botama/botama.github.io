bal_kéz = True  # támad
jobb_kéz = True  # támad

# ha az igaz-hamis értéket átalakítjuk az int függvénnyel,
# akkor 1 vagy 0 értéket fogunk kapni (igaz = 1, hamis = 0)
print("Támadás erőssége:", int(bal_kéz) + int(jobb_kéz))
