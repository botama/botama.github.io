varázsige_sablon = "Amperiatus golemi..."  # sablon varázsige

célpont_neve = input("Célpont neve:")  # bekérés a varázslótól
célpontok_száma = input("Célpontok száma:")  # bekérés a varázslótól

# készítsük el a teljes varázsigét a bekért értékekből
varázsige = varázsige_sablon + célpont_neve * int(célpontok_száma)

print(varázsige)
