# Ez egy szokványos értékadás
Amun = "Perisis"  # Az Amun valtozó vegye fel a "Persis" értéket

# Most pedig megkérjük a varázslót, hogy adjon értéket a Drakum változónak
Drakum = input("Senisis? ")  # A Drakum változó vegye fel a bekért értéket

print(Amun, Drakum)  # Megjelenítjük a három tároló tartalmát
