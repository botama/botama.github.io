Amun = "Perisis"  # Az Amun tárolóba belerakjuk a "Persis" értéket
Drakum = "Senisis"  # A Drakum tárolóba belerakjuk a "Senisis" értéket
Trias = "Noram"  # A Trias tárolóba belerakjuk a "Noram" értéket

print(Amun, Drakum, Trias)  # Megjelenítjük a három tároló tartalmát
