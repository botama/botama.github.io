Démon_kora = "147"  # Szövegesen megadtunk egy tulajdonságot
print(Démon_kora, type(Démon_kora))

Démon_kora = int("147")  # A szöveget átalakítjuk egész számmá
print(Démon_kora, type(Démon_kora))

Démon_gonosz_e = "True"  # Szövegesen megadtunk egy tulajdonságot
print(Démon_gonosz_e, type(Démon_gonosz_e))

Démon_gonosz_e = bool("True")  # A szöveget átalakítjuk igaz-hamis értékké
print(Démon_gonosz_e, type(Démon_gonosz_e))
